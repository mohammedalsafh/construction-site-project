﻿using System.ComponentModel.DataAnnotations;

namespace CPIS_358_project.Models
{
    public class PaymentModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Card Name is required")]
        [MinLength(5, ErrorMessage = "Card holder name is too short (min 5 chars).")]
        public string CardName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Card Number is required")]
        // Matches your JS rule: EXACTLY 17 digits
        [RegularExpression(@"^\d{17}$", ErrorMessage = "Card number must be exactly 17 digits.")]
        public string CardNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Expiry Date is required")]
        public DateTime ExpDate { get; set; }

        [Required(ErrorMessage = "CVV is required")]
        [RegularExpression(@"^\d{3,4}$", ErrorMessage = "CVV must be 3 or 4 digits.")]
        public string CVV { get; set; } = string.Empty;
    }
}