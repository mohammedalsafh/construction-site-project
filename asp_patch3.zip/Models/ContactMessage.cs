﻿using System.ComponentModel.DataAnnotations;

namespace CPIS_358_project.Models
{
    public class ContactMessage
    {
        public int Id { get; set; }

        // Same Strict Rule: First Name + Space + Last Name
        [Required(ErrorMessage = "Name is required")]
        [RegularExpression(@"^[A-Za-z]+ [A-Za-z]+$", ErrorMessage = "Must be First and Last name (letters only).")]
        public string Name { get; set; } = string.Empty;

        // Same Strict Rule: No @. and must have domain
        [Required(ErrorMessage = "Email is required")]
        [RegularExpression(@"^[^@]+@[^.][^@]*\.[^@]+$", ErrorMessage = "Invalid Email Format.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a subject")]
        public string Subject { get; set; } = string.Empty;

        [Required(ErrorMessage = "Message is required")]
        [MinLength(10, ErrorMessage = "Message must be at least 10 characters.")]
        public string Message { get; set; } = string.Empty;
    }
}