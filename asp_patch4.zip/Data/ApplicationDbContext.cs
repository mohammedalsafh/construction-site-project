﻿using CPIS_358_project.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace CPIS_358_project.Data
{
    //this class will handle the connection to the database
    public class ApplicationDbContext : DbContext
    {
        //this will set up the database configuration
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        //this will create table for users in the database
        public DbSet<User> Users { get; set; }

        //this will create the table for contact messages in the database
        public DbSet<ContactMessage> ContactMessages { get; set; }

        //this will create the table for payments in the database
        public DbSet<PaymentModel> Payments { get; set; }
    }
}