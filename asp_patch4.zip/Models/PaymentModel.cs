﻿using System.ComponentModel.DataAnnotations;

namespace CPIS_358_project.Models
{
    //This class handle the payment info when a user buy something
    public class PaymentModel
    {
        //we need ID for the database to track this specific payment
        public int Id { get; set; }

        [Required(ErrorMessage = "Card Name is required")]
        //we make sure the name isnt too short it need at least 5 letters to be a real full name
        [MinLength(5, ErrorMessage = "Card holder name is too short (min 5 chars).")]
        public string CardName { get; set; } = string.Empty;//will get and set the card holder name

        [Required(ErrorMessage = "Card Number is required")]
        //The rule here matches what we did in js it must be exactly 17 numbers no more no less
        [RegularExpression(@"^\d{17}$", ErrorMessage = "Card number must be exactly 17 digits.")]
        public string CardNumber { get; set; } = string.Empty;//will get and set the card number

        [Required(ErrorMessage = "Expiry Date is required")]
        public DateTime ExpDate { get; set; }//will get and set the expiration date of the card

        [Required(ErrorMessage = "CVV is required")]
        //this checks the security code on the back it has 3 or 4 numbers
        [RegularExpression(@"^\d{3,4}$", ErrorMessage = "CVV must be 3 or 4 digits.")]
        public string CVV { get; set; } = string.Empty;//will get and set the CVV code
    }
}