﻿using System.ComponentModel.DataAnnotations;

namespace CPIS_358_project.Models
{
    //this class handles the data when someone fill out the "Contact Us" form
    public class ContactMessage
    {
        //we need ID for the database so we can keep track of each message
        public int Id { get; set; }

         
        //these are rule says they must type a First Name then a space then Last Name
        //we only allow letters so no numbers or special symbols here
        [Required(ErrorMessage = "Name is required")]
        [RegularExpression(@"^[A-Za-z]+ [A-Za-z]+$", ErrorMessage = "Must be First and Last name (letters only).")]
        public string Name { get; set; } = string.Empty;

        //this ensures they give us a proper email address
        //it checks for the "@" sign and makes sure they don't put a dot right after it
        [Required(ErrorMessage = "Email is required")]
        [RegularExpression(@"^[^@]+@[^.][^@]*\.[^@]+$", ErrorMessage = "Invalid Email Format.")]
        public string Email { get; set; } = string.Empty;

        //we make the user to actully pick a topic from the list they can't leave it empty
        [Required(ErrorMessage = "Please select a subject")]
        public string Subject { get; set; } = string.Empty;

        //the message that the user send to us from contact 
        //we added a rule that it has to be at least 10 letters long
        [Required(ErrorMessage = "Message is required")]
        [MinLength(10, ErrorMessage = "Message must be at least 10 characters.")]
        public string Message { get; set; } = string.Empty;
    }
}