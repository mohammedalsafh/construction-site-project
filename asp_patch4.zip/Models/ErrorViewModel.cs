namespace CPIS_358_project.Models
{
    //this model is used when something is wrong it will help the error page to show what happened
    public class ErrorViewModel
    {
        //this holds the unique ID for the request that failed 
        //we use this to track errors the '?' means it is allowed to be empty
        public string? RequestId { get; set; }

        //this is a  logic for checking. 
        //it will tell the view "True" if we have an ID or "False" if the ID is missing so we don't empty text
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}