using System.Diagnostics;
using CPIS_358_project.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using CPIS_358_project.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CPIS_358_project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        //connecting the database 
        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            //will get the current username from session to see who is using the site
            string? currentUser = HttpContext.Session.GetString("username");

            //will check if user is logged in
            if (!string.IsNullOrEmpty(currentUser) && currentUser != "guest")
            {
                SetCookies("username", currentUser);
            }
            else
            {
                //if the user isnt logged in set them as guest
                SetCookies("username", "guest");
                HttpContext.Session.SetString("username", "guest");
            }

            return View();
        }

        public IActionResult Signup() { return View(); }
        public IActionResult Login() { return View(); }
        public IActionResult ForgotPassword() { return View(); }

        //will handle the signup form
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Signup(User user)
        {
            //will check if this email is already in the database
            var existingUser = _context.Users.FirstOrDefault(u => u.UserE == user.UserE);

            if (existingUser != null)
            {
                //will see if email exists if yes it will show error
                ModelState.AddModelError("UserE", "This email is already registered.");
                return View(user);
            }

            //if everything is correct
            if (ModelState.IsValid)
            {
                //will add new user and save
                _context.Add(user);
                await _context.SaveChangesAsync();

                //will log them in
                SetSession("username", user.UserE);
                return RedirectToAction("Store");
            }
            return View(user);
        }

        //this will handle the login form
        [HttpPost]
        public IActionResult Login(User userLogin)
        {
            //we dont need name or phone for login so we ignore them
            ModelState.Remove("FullName");
            ModelState.Remove("PhoneNumber");

            if (ModelState.IsValid)
            {
                //search for user with his matching email and password
                var userFound = _context.Users
                    .FirstOrDefault(u => u.UserE == userLogin.UserE && u.UserP == userLogin.UserP);

                if (userFound != null)
                {
                    //if user found start the session
                    SetSession("username", userFound.UserE);
                    return RedirectToAction("Store");
                }
                else
                {
                    //if the email or pass were wrong 
                    ViewBag.Error = "Invalid Email or Password";
                }
            }
            return View(userLogin);
        }

        //will handle updating the password 
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                //searching for the user by email
                var userToUpdate = _context.Users.FirstOrDefault(u => u.UserE == model.UserE);

                if (userToUpdate != null)
                {
                    //update to the new password
                    userToUpdate.UserP = model.NewP;
                    _context.Update(userToUpdate);
                    await _context.SaveChangesAsync();

                    //go back to login page
                    return RedirectToAction("Login");
                }
                else
                {
                    //if the email wasnt foound
                    ModelState.AddModelError("UserE", "Email not found.");
                }
            }
            return View(model);
        }

        //logic for logging out
        public IActionResult Logout()
        {
            //will clear all session data
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        //other pages
        public IActionResult About()
        {
            return View();
        }

        public IActionResult ProductInfo()
        {
            return View();
        }

        public IActionResult Services()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        //will handle contact form messages
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Contact(ContactMessage model)
        {
            if (ModelState.IsValid)
            {
                //will save the message to database
                _context.Add(model);
                await _context.SaveChangesAsync();

                //will show success message
                ViewBag.Message = "Thank you! Your message has been sent to our database, we will contact you as soon as possible.";

                //will clear the form
                ModelState.Clear();
                return View();
            }

            return View(model);
        }

        //payment page logic
        public IActionResult Payment()
        {
            //will check if user is logged in by looking for username in session
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        //will handle payment submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Payment(PaymentModel model)
        {
            //will check if card is expired or close to expiry in the same month
            if (model.ExpDate < DateTime.Today)
            {
                ModelState.AddModelError("ExpDate", "Your card is expired or close to expiry date.");
            }

            if (ModelState.IsValid)
            {
                //will save payment info
                _context.Add(model);
                await _context.SaveChangesAsync();

                ViewBag.SuccessMessage = "Your purchase is complete! To track your order, contact us through WhatsApp or Email.";

                //will clear form
                ModelState.Clear();
                return View();
            }

            return View(model);
        }

        //store page logic
        public IActionResult Store()
        {
            //get the username from session to check if they are allowed here
            string? username = HttpContext.Session.GetString("username");

            //will only let logged in users see the store
            if (username == null || username == "guest")
            {
                return RedirectToAction("Login");
            }

            return View();
        }

        //delete account button logic 
        public async Task<IActionResult> DeleteAccount()
        {
            //will get the email of the user who wants to delete their account
            string? userEmail = HttpContext.Session.GetString("username");

            if (userEmail != null)
            {
                // find the user in database
                var userToDelete = _context.Users.FirstOrDefault(u => u.UserE == userEmail);

                if (userToDelete != null)
                {
                    // remove them
                    _context.Users.Remove(userToDelete);
                    await _context.SaveChangesAsync();

                    // logout
                    HttpContext.Session.Clear();

                    return RedirectToAction("Signup");
                }
            }
            return RedirectToAction("Index");
        }

        //helper to set cookies
        [Authorize]
        public IActionResult SetCookies(string cookieName, string cookieValue)
        {
            //will setup the rules for the cookie
            CookieOptions options = new CookieOptions
            {
                //it will disappear after 10 days
                Expires = DateTime.Now.AddDays(10),

                //javascript cannot read this cookie for safety
                HttpOnly = true,

                //will make sure cookie is sent over secure https connection
                Secure = true,

                //will prevents the cookie from being sent to other sites
                SameSite = SameSiteMode.Strict,
            };

            //will save the cookie in the browser
            Response.Cookies.Append(cookieName, cookieValue, options);
            return Ok("Cookies has been set.");
        }

        //helper to set session
        [Authorize]
        public IActionResult SetSession(string sessionId, string value)
        {
            //will save data to the server session
            HttpContext.Session.SetString(sessionId, value);
            return RedirectToAction("Index");
        }
    }
}