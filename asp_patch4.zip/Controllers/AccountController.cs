﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace CPIS_358_project.Controllers
{
    //this controller handles the account page
    public class AccountController : Controller
    {
        //this function shows the main index page
        public IActionResult Index()
        {
            //will get the id that is saved in the session
            ViewBag.sessionId = HttpContext.Session.GetString("id");

            //will get the username that is saved in the session
            ViewBag.sessionUserName = HttpContext.Session.GetString("username");

            //will open the view page
            return View();
        }
    }
}