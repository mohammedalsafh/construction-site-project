using Microsoft.EntityFrameworkCore;
using CPIS_358_project.Data;
namespace CPIS_358_project
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //this will start building the web application
            var builder = WebApplication.CreateBuilder(args);

            //this will add support for controllers and views MVC
            builder.Services.AddControllersWithViews();

            //this will connect to the database using the connection string from settings
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            //this will setup memory cache to store temporary data
            builder.Services.AddDistributedMemoryCache();

            //this will setup session to keep user logged in
            builder.Services.AddSession(options => {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // session expires after 30 mins
                options.Cookie.IsEssential = true; // cookie is needed for the app to work
            });

            //this will build the app with all the settings above
            var app = builder.Build();

            //this will check if we are NOT in development mode (meaning we are live)
            if (!app.Environment.IsDevelopment())
            {
                //if app crashes then go to the error page
                app.UseExceptionHandler("/Home/Error");
                // use strict security settings
                app.UseHsts();
            }

            //this will force users to use secure https connection
            app.UseHttpsRedirection();

            //this will enable routing to find the correct pages
            app.UseRouting();

            //this will enable authorization (checking permissions)
            app.UseAuthorization();

            //this will enable the session feature we setup earlier
            app.UseSession();

            //this will load static files like images and css
            app.MapStaticAssets();

            //this will set the default page to open (Home Controller -> Index Action)
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}")
                .WithStaticAssets();

            //this will start the website
            app.Run();
        }
    }
}