﻿using CPIS_358_project.Data;
using CPIS_358_project.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CPIS_358_project.Controllers
{
    public class ServicesController : Controller
    {
        private readonly CPIS_358_projectContext _context;

        public ServicesController(CPIS_358_projectContext context)
        {
            _context = context;
        }
        //makes the user login first,then be able to access services page.
        [Authorize]
        
        public async Task<IActionResult> Index()
        {
            //will get the list from the db and sending it to the view
            return View(await _context.Services.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                //if the d isnt found
                return NotFound();
            }

            var services = await _context.Services
                .FirstOrDefaultAsync(m => m.ID == id);
            if (services == null)
            {
                //if id found but theres no service
                return NotFound();
            }

            return View(services);
        }
        public IActionResult Create()
        {
            //this will show the empty form here
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,Profession,yearsOfExperience")] Services services)
        {
            if (ModelState.IsValid)
            {
                //if everything is filled out right we add it
                _context.Add(services);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            //if something was wrong go back to the form so they can fix it
            return View(services);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //grabbing the existing data so we can fill the inputs
            var services = await _context.Services.FindAsync(id);
            if (services == null)
            {
                return NotFound();
            }
            return View(services);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Profession,yearsOfExperience")] Services services)
        {
            if (id != services.ID)
            {
                //security check to make sure the ids match
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //update the database with new info
                    _context.Update(services);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    //just in case someone else deleted it while we were editing
                    if (!ServicesExists(services.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(services);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //find the service we want to delete so we can show the confirmation page
            var services = await _context.Services
                .FirstOrDefaultAsync(m => m.ID == id);
            if (services == null)
            {
                return NotFound();
            }

            return View(services);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            //this is where the actual deleting happens after they click confirm
            var services = await _context.Services.FindAsync(id);
            if (services != null)
            {
                _context.Services.Remove(services);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ServicesExists(int id)
        {
            //helper to check if a service id exists in the db
            return _context.Services.Any(e => e.ID == id);
        }

        public async Task<IActionResult> SearchForm()
        {
            //show the search page
            return View();
        }

        public async Task<IActionResult> SearchResults(string SearchString)
        {
            if (_context.Services == null)
            {
                //check if the table is even there
                return Problem("Entity set 'CPIS-358-project' is null");
            }
            //filter the list based on the profession name they typed
            var filteredService = await _context.Services.Where(x => x.Profession.Contains(SearchString)).ToListAsync();
            return View("Index", filteredService);
        }
    }
}