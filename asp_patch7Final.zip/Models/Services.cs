﻿namespace CPIS_358_project.Models
{
    public class Services
    {
        public int ID { get; set; }

        //this is name of the service provider
        public required string Name { get; set; }

        //this is storing the profession type here
        public required string Profession { get; set; }

        //this is how many years have they been doing this job
        public int yearsOfExperience { get; set; }

        public Services()
        {

        }
    }
}